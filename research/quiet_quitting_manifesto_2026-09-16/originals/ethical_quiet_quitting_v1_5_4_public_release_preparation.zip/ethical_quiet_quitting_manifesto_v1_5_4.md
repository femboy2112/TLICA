---
title: "The Ethical Quiet Quitting Manifesto"
subtitle: "Repair First. Stop Hiding the Damage. Withdraw Only When Repair Fails."
author: "Leah"
date: "August 16, 2026"
version: "1.5.4"
runningtitle: "The Ethical Quiet Quitting Manifesto"
tagline: "We withdraw the subsidy, not the integrity."
---

# Preamble

**Quiet quitting proper is not outright refusal of labor.** It retains the defensible baseline of the job and withdraws only the unowned excess demanded above it. Whether and when outright refusal is ethical is a separate question this manifesto does not purport to settle.

Work is a cooperative system, but employment is not a meeting of equal power. The worker's most immediate remaining power is limited but real: how they perform the paid role and whether they continue donating excess. Economic necessity constrains even that choice. The employer controls pay, staffing, schedules, rules, discipline, and much of the field in which that labor must act.

That asymmetry creates different ethical ideals and different burdens. Here, an **ideal** is an orienting ethical standard, not an optional courtesy, a description of every real workplace, or a claim that the burdens are equal. The worker-side ideal is the conscious and responsible use of the limited power the worker actually exercises: competent, safe, honest labor within the real job, and ownership of chosen acts within what the worker can reasonably know and control. The employer-side ideal is humane restraint and affirmative repair proportionate to its greater control: sufficient resources, intelligible priorities, usable feedback channels, and some plausible connection between effort and a self-directed future. These are not mirror images. Greater authority, information, and reach create the larger affirmative burden and the wider consequences. For those who hold concentrated power, humane restraint is not pathological tolerance of deception, serious harm, or deliberate destruction. It is the refusal to use concentrated power carelessly or punitively. No worker owes unlimited self-erasure to keep a broken arrangement looking functional.

No system is perfect, and neither ideal requires perfection. Ordinary friction, a hard week, a minor defect, or an isolated repairable mistake does not by itself create the conditions for ethical quiet quitting proper. At minimum, quiet quitting proper requires a material and persistent mismatch between the defensible job and operative expectations, and pathways toward meaningful correction must be absent, unsafe, reasonably judged futile, unreasonably costly, or limited to assimilation rather than repair; the further ethical conditions below still apply. Imperfection calls for proportionate repair. Structural closure is what makes withdrawal the last boundary.

Quiet quitting proper should not be the first move. It should be the last honest boundary after good-faith repair has failed.

> **The central rule:** Try to make the workplace better in every ethical way reasonably available. When those pathways have been tested and closed, stop using private sacrifice to counterfeit institutional health. Perform the real job safely, honestly, and sustainably. That is quiet quitting proper.

Repair first is not permission-seeking. It helps the worker learn what is true before exercising power and preserves the causal story of what follows. It does not give the employer a right to endless chances, force the worker through danger or retaliation, or transfer responsibility for institutional repair to the person with the least control over it.

This argument finally crystallized through one workplace: chronic under-capacity, attempted repair, and the hidden effort that kept incompatible demands looking compatible. I offer the pattern for recognition and criticism, not as a template other workers must prove they fit before they are allowed a boundary.

# 1. What Quiet Quitting Is, and What It Is Not

This manifesto uses **quiet quitting proper** in a precise sense:

> Quiet quitting proper means competently performing the work one is paid and reasonably expected to perform, while ceasing the discretionary, uncompensated, unsustainable, or identity-consuming excess that has silently become part of the institution's operating model.

In ordinary speech, however, **quiet quitting** is a much looser label. It may be used for a worker reserving capacity for moonlighting or a second job; setting an ordinary boundary; disengaging for reasons unrelated to the structure of the job; or deliberately trying to do as little as possible regardless of whether the bargain is fair. Those are not one moral object. Some may be harmless or justified; some may reflect a worker's tacit adaptation to the lived bargain; some may cross into neglect, retaliation, or misconduct. A shared label does not make the acts ethically identical, and the label alone settles none of them.

My question is narrower and begins with my own case: what does quiet quitting proper look like when I am actively trying to be a good person while doing it—to do good, avoid unnecessary harm, seek capital-T Truth to the best of my understanding, and give everyone affected, including the employer, a fair shake—while withdrawing the unowned excess? A fair shake is not a fiction of equal footing; it means judging each actor's choices by what they could reasonably know and control. This is not a claim of moral superiority or a verdict on every worker described by the broader label. It is an attempt to remain answerable to reality and other people while refusing self-erasure: to withdraw the subsidy without withdrawing integrity.

**A disclosure about how I arrived here.** I did not begin by practicing this framework. At earlier jobs, I engaged in what the broader public label calls quiet quitting in ways I would not now call quiet quitting proper. At times I treated my own needs as settling the whole question. The mistake was not refusing self-sacrifice. It was failing to test what I thought was true against reality, trace foreseeable effects on other people, or distinguish withdrawing an unowned subsidy from simply putting myself first. I do not offer this manifesto to retroactively certify those choices; some of them do not survive its test.

I kept returning to withdrawal despite real trepidation because *something felt right about quiet quitting that I couldn't put my finger on*. That feeling was a clue, not a verdict. Reflection on the consequences—and on the distance between what I thought was true and what I could later justify as true—showed me both parts of the problem: a worker can be responding to a real structural mismatch and still respond to it unethically.

This manifesto is the result of forcing that unresolved intuition through truth-testing, consequence-awareness, and responsibility. My responsibility for the acts I chose does not put the parties on equal footing or erase the institution's larger structural burden. This disclosure explains my route to the framework. It is not a confession other workers owe before the facts of their boundary can be recognized.

Except where the broader public label is explicitly under discussion, **quiet quitting** below is shorthand for **quiet quitting proper**.

For the ethical quiet quitter proper, the relation runs one way:

$$
\boxed{\text{quiet quitter proper}\ \Longrightarrow\ \text{structural or managerial expectations exceed the defensible job baseline}.}
$$

The baseline is not the least an employer can compel without consequence. It is the compensated, reasonably defined role—including legitimate professional and safety standards—performed competently at a sustainable pace. Quiet quitting proper begins when structural or managerial expectations exceed that baseline and the worker stops supplying the unowned excess.

That excess condition is necessary, not sufficient. The pathway and ethical conditions below distinguish quiet quitting proper from ordinary boundary-setting, misconduct, or collective pressure.

It is not refusing to work. It is refusing to donate an undefined second job.

No worker must earn permission to stop making a genuinely voluntary gift. An institution does not acquire a new moral right to notice, staging, or handoff merely because it organized itself around labor it never sustainably resourced. Where a boundary may touch other people, responsible power means seeing what can be seen and owning what one actually chooses; it does not mean accepting responsibility for conditions controlled elsewhere.

Quiet may be spoken or unannounced. Where openness is safe and useful, a worker can state the boundary plainly. Where openness invites retaliation, silence is not automatically dishonesty. What ends is the donation of unowned excess, not the worker's integrity.

The real job is the work paid for and reasonably expected under the role and its professional standards, not every task normalized through hidden sacrifice. Repetition does not turn an unsustainable subsidy into a permanent duty.

Simply declining a genuinely optional extra is ordinary boundary-setting. It can be wholly ethical without being the narrower phenomenon named here. Quiet quitting proper becomes distinct when operative structural or managerial expectations exceed the defensible job baseline. The gap may appear in the words—the codified role is so vague that no defensible boundary can be identified, or is internally contradictory; in the practice—the real job materially extends or contradicts the written one without agreement, resources, or reciprocal adjustment; or in the operating conditions—volume, pace, staffing, equipment, or priorities make competent, sustainable performance of the nominal bundle impossible. An “optional” extra enforced through pressure, evaluation, or discipline is not optional in practice.

Correction clarifies the role, reconciles and prioritizes conflicting standards, resources the work, or negotiates expanded duties the worker can actually reject. Assimilation says: absorb the contradiction, supply the missing capacity, and let hidden compensating labor become the job.

> **Assimilation is not correction. It is the defect becoming the worker's identity and duty.**

In a healthy, properly resourced workplace, a worker performing this same baseline conduct simply looks average: the job is being done competently at a sustainable pace. There is nothing there to call quiet quitting. In a broken workplace, the same conduct looks like withdrawal only because the institution had mistaken excess for capacity.

> **The behavior is ordinary work. The phenomenon is the institution discovering that it had mistaken a subsidy for the job.**

It is not:

- sabotaging output;
- deliberately working below a reasonable professional standard;
- falsifying records, hiding urgent risks, or manufacturing failures;
- concealing serious safety risks or manufacturing harm and calling it ordinary quiet quitting;
- secretly creating bottlenecks that would not otherwise exist and presenting them as ordinary reduced effort;
- retaliating against a decent direct supervisor for failures above their authority;
- performing helplessness as a strategy;
- proof that the worker rejects ambition, discipline, or difficult work;
- confusing revenge with a boundary.

It is:

- working at a sustainable professional pace;
- fulfilling the defined role without silently absorbing every missing role around it;
- declining chronic unpaid availability and unbounded role expansion;
- refusing to turn every managerial failure into a personal emergency;
- making incompatible demands visible instead of privately reconciling them through exhaustion;
- preserving energy, time, health, and agency for a life beyond the institution;
- reserving exceptional effort for work, people, and futures that can meaningfully receive it.

The ethical distinction is simple:

$$
\boxed{\text{Ceasing to subsidize a broken system} \neq \text{manufacturing damage to a system}.}
$$

That distinction defines **individual quiet quitting proper**. It does not decide the morality of strikes, boycotts, slowdowns, coordinated work-to-rule, or other collective action. Collective power can intentionally create pressure and disruption; its ethics are addressed in Section 9.

The warnings are different because the power is different. For workers, the label cannot turn bad faith, retaliation, deliberate neglect, or conduct that belongs to another category into ethical action; where the act is consciously chosen, name it honestly and own it within what can reasonably be known and controlled. For employers, the existence of unlike cases cannot erase the structurally produced one or justify treating every withdrawal as laziness or misconduct. Because employers control classification, discipline, staffing, and repair, they bear the larger duty to distinguish the cases fairly before acting.

> **A workplace can teach quiet quitting before a worker ever calls it that.**

This makes no statistical claim about what most people described by the broader label do. My case is one explicitly articulated version of a structural possibility developed in the next section, not proof that less articulated cases lack reasons or integrity. If even this consciously examined path reaches withdrawal, an institution cannot make articulate self-explanation another condition of taking structurally produced withdrawal seriously.

# 2. Why Workers Withdraw

In the narrower case developed here, withdrawal need not mean that the worker stopped caring. Care may persist after actionable pathways to repair have closed.

My working hypothesis is that many cases described by the broader public label may share this structure without sharing this manifesto's explicit reasoning. The posture can emerge gradually: the environment teaches a person what effort leads to, while that person's circumstances and values shape what they continue to give, what they protect, and what they withdraw. They may settle into the mindset without ever formalizing it as an ethical program. That is a proposed explanation, not a measured prevalence claim.

This manifesto is not a defense of apathy. It addresses workers who try to repair what they reasonably can, tell the truth as far as they can, and eventually stop feeding a system that converts every rescue into evidence that no rescue was needed.

The worker learns, repeatedly, that:

$$
\text{speaking} \nrightarrow \text{change},
$$

$$
\text{excellent work} \nrightarrow \text{meaningful advancement},
$$

$$
\text{identifying a problem} \nrightarrow \text{repair},
$$

$$
\text{sacrifice} \rightarrow \text{the new minimum expectation}.
$$

A promotion may exist in name but not in meaning. Requests for help may be acknowledged but not acted upon. The chain of command may transmit orders downward while filtering inconvenient reality upward. The employee may still possess the physical ability to act, but the routes connecting action to a self-directed future have narrowed or closed.

That is not merely low morale. It is a contraction of practical agency.

Yet perceived closure can be mistaken, temporary, or caused by an ordinary communication failure.[^1] That is why ethical quiet quitting begins by testing the closure where doing so is reasonably safe and useful. The test serves the worker's own judgment. It is not a presumption that the institution deserves another appeal.


## 2.1 The Exit Fallacy: "Why Not Just Get Another Job?"

The standard objection to quiet quitting is: "If you can still do the job properly, why not keep doing it here - or just get another job?"

It sounds like common sense only because it assumes exit is immediate, costless, and safe.

> **"Why not just get another job?" is often the labor-market version of "If they cannot afford bread here, let them eat cake."** It answers a constraint by assuming access to the very resources the constraint has already taken away.

The comparison is deliberate hyperbole. It does not equate the suffering involved, and it makes no historical claim about who coined the phrase. It identifies the same error of answering a constraint by recommending an option the constrained person may not actually be able to reach.

People need jobs to live. Wages keep housing, food, medicine, utilities, transportation, and the rest of ordinary survival available. For workers without enough financial cushion to absorb an income gap, missing even one paycheck can produce immediate material harm. A job search itself consumes scarce resources: time, attention, internet access, transportation, scheduling flexibility, references, emotional bandwidth, and tolerance for uncertainty. A bad job can consume exactly the time and mental clarity required to escape it.[^2]

In agency terms, another job may be formally possible without being a live option:

$$
\mathcal E_t^{\mathrm{formal}}\neq\varnothing
\quad\nRightarrow\quad
\mathcal E_t^{\mathrm{viable}}\neq\varnothing.
$$

A vacancy may exist somewhere. That does not mean this worker can reach it, be hired, survive the gap before the first paycheck, accept its schedule, replace lost benefits, or risk losing current income while applying. Thus:

$$
\text{another job exists}
\nRightarrow
\text{another job is presently reachable},
$$

and

$$
\text{ability to perform this job}
\nRightarrow
\text{ability to survive an employment transition}.
$$

The current employer can also consume the worker's exit capacity through overtime, unstable scheduling, exhaustion, and chronic crisis. Telling that worker to leave can amount to demanding that they finance the employer's failure with unemployment risk.

Quiet quitting proper can therefore be a bridge, not merely a destination. By withdrawing unsustainable excess while preserving competent core work and income, a worker may recover enough time, health, and cognitive capacity to search, train, organize, or build a genuinely live exit. In this role, quiet quitting is configurational action: it can create the conditions under which leaving becomes possible. It can also bring discipline, retaliation, lost advancement, or dismissal. Reclaimed power is real power, with real risk.

None of this means a worker should never leave. A genuinely live better option should be pursued when appropriate. The point is that its liveness must be assessed, not presumed. Continued attendance does not prove consent, satisfaction, or endorsement. It may mean only that rent is due.

The wage relation does not produce a clean binary between fully invested and gone. One important intermediate state is a person who still needs the wage but can no longer rationally donate hidden heroics. That is precisely the terrain of quiet quitting. If management answers that state with more pressure rather than restored pathways, ordinary mistake risk and forced triage can intensify together.


## 2.2 Grind Culture: Hard Work Needs Somewhere to Go

This manifesto is not an attack on ambition, discipline, or hard work. Deep effort can be a rational joy when it builds a future the worker can recognize as their own. There are jobs, crafts, teams, missions, and businesses for which long hours and difficult work can be rational, joyful, and personally meaningful. A person may willingly grind because the effort produces mastery, security, ownership, belonging, influence, credible advancement, or a future they genuinely recognize as their own.

That is good. Someone who has found work that resonates with them should be glad they found it.

The error begins when a contingent fit is converted into a universal character test:

> **I can grind here, therefore anyone who does not grind here is lazy, weak, entitled, or morally unserious.**

Meaningful grind is not generated by attitude alone. It is co-produced by a worker, a role, a manager, a team, a reward structure, a life stage, and a particular moment in the world. Access to it can depend heavily on chance: meeting the right people, entering the right field at the right time, having enough stability to take a risk, finding coworkers whose own versions of commitment are compatible, and landing somewhere that can actually receive what one is capable of giving.

A person can search for that alignment, cultivate skills, take risks, and improve the odds. They cannot unilaterally command a workplace to become meaningful, force a manager to become trustworthy, create advancement where none exists, or make everyone around them participate in the same reciprocal project. The right attitude cannot, by itself, manufacture the right social and material field.

Schematically, discretionary grind depends on more than character:

$$
G_t^{\mathrm{disc}}
=
f(R_t,O_t,Q_t,P_t,C_t,B_t),
$$

where:

- $R_t$ is personal resonance with the work;
- $O_t$ is ownership, autonomy, or meaningful influence;
- $Q_t$ is tangible reciprocal return;
- $P_t$ is a credible pathway from present effort to a self-directed future;
- $C_t$ is the surrounding field of compatible coworkers, leadership, and institutional support;
- $B_t$ is the worker's available health, time, and cognitive bandwidth.

This is not a psychometric formula. It is a reminder that exceptional effort is an ecological outcome, not a scalar reading of moral worth.

Grind ideology often collapses the whole vector into one flattering verdict:

$$
\text{high discretionary effort}
\approx
\text{strength, seriousness, and virtue}.
$$

But the valid implications are much weaker:

$$
\begin{aligned}
\text{high discretionary effort}
&\nRightarrow
\text{superior character},\\
\text{withdrawal of excess}
&\nRightarrow
\text{weakness or absence of ambition}.
\end{aligned}
$$

The same person may grind relentlessly for their own company, their art, their family, a team they trust, a craft they love, or an employer that tangibly shares the return—and quiet quit at an institution where extraordinary effort merely disappears into the next quarter's minimum expectation. That is not necessarily inconsistency. The objects are different.

> **I would grind for a company if the grind tangibly built something I could recognize as mine: security, mastery, influence, belonging, ownership, a credible future, or a mission I actually share. I will not grind merely to prove that I am hard, that I work hard, that I am not weak, or that I can endure being ground down.**

When tangible return is absent, grind culture can substitute an **identity wage**: “I am hard. I work hard. I am not weak. I am a grinder.” Alison R. Buck uses *identity wages* in her study of game-industry labor.[^3] I adapt the term here for a narrower warning beyond that domain. That identity may be personally chosen and genuinely valuable to someone. But it cannot be treated as compensation owed by the worker to the employer. If suffering itself becomes proof of virtue, then exploitation becomes self-sealing: every injury demonstrates toughness, every boundary demonstrates weakness, and no evidence can show that the arrangement is a bad bargain.

Hard work does not need to be pleasant every hour to be worthwhile. Meaningful projects include boredom, frustration, repetition, sacrifice, and failure. Nor does personal non-resonance erase the worker's core obligations after accepting wages. The distinction concerns **discretionary excess**: the unbounded energy above competent, safe, honest performance.

Quiet quitting proper is therefore not necessarily anti-work or anti-ambition. It can be the refusal to let one institution monopolize a person's highest effort without providing a credible reciprocal basis. The recovered capacity may go into education, art, caregiving, organizing, recovery, a job search, a future business, or another workplace capable of receiving it.

> **Hard work becomes investment when it builds an owned future. Without that connection, the same effort becomes depletion.**

This does not make every difficult demand illegitimate. Workers should not dismiss one merely because it does not feel inspiring. But managers must not use the most personally resonant employee as the neutral baseline for everyone else. Passion is real, powerful, and partly contingent. It is not payroll infrastructure.

The question of whether hard work still builds an owned future has a specifically American form.


## 2.3 The Hard-Working American and the American Dream

In the strand of American culture examined here, the **hard-working American** and the **American Dream** are not independent ideas. They are the input and output sides of one social promise.[^4]

> **The hard-working American supplies the effort. The American Dream is the future that effort is supposed to make reachable.**

The input-side ideal praises discipline, reliability, endurance, initiative, contribution, and the willingness to sacrifice now for something larger later. The output-side ideal says that such effort can plausibly become a stable life: enough material security to breathe, a home or other durable stake in the world, the ability to support a family, education and opportunity, retirement, ownership, upward movement, independence, dignity, and a future increasingly shaped by the worker rather than merely endured by them.

The promise has never meant that every hardworking person is guaranteed every desired outcome. Chance, starting position, health, geography, timing, social connection, discrimination, family obligations, and the actions of other people all affect what becomes reachable. But the ideal retains moral force only while the causal arrow remains credible:

$$
\text{hard work}
\longrightarrow
\text{a materially and personally owned future}.
$$

A worker can tolerate uncertainty in that arrow. They cannot rationally invest forever after it has become indistinguishable from fiction.

When wages cannot support a stable life, schedules destroy the worker's ability to plan one, promotions change titles without changing futures, benefits remain precarious, ownership never increases, and every burst of productivity is converted into the next permanent minimum, the worker's own estimate may begin to change. Let \(\widehat P_t\) denote that judgment; schematically, not as a fitted population estimate:

$$
\widehat P_t(\text{owned future}\mid\text{additional effort here})\downarrow.
$$

The critical word is **here**. The worker may still believe in hard work. They may still want the house, the family, the craft, the business, the security, the independence, or the chance to give their children more. What has collapsed is the belief that additional sacrifice for this institution is a live route toward those goods.

At that point, appeals to the "hard-working American" can become an identity wage dressed in national mythology. The institution continues demanding the input after severing it from the promised output:

> Work harder because hardworking people are good people. Endure because endurance proves character. Be proud that you can carry what we refuse to repair.

But a social bargain cannot remain coherent as a one-sided character demand. An employer cannot substitute borrowed national ideals for pay, security, ownership, advancement, or meaningful influence. Patriotism is not compensation, and suffering is not evidence that a future is being built.

> **The American Dream cannot function as deferred compensation after the pathway from present labor to that future has ceased to be credible.**

This is one reason quiet quitting follows pathway closure. The worker does not necessarily reject the Dream. They cease treating the employer as its vehicle. They preserve competent core work because survival still depends on the wage, while withdrawing the discretionary sacrifice that no longer appears to purchase any owned future.

Schematically:

$$
\text{dream-path closure}
\longrightarrow
\text{withdrawal of discretionary investment}.
$$

Quiet quitting can therefore preserve the work ethic rather than destroy it. The reclaimed effort may be redirected toward education, recovery, family, art, organizing, a second income, a job search, a future business, or another institution where sacrifice and return remain causally connected. The person is not necessarily refusing to build. They are refusing to keep building a future that belongs entirely to someone else.

The proportionality rule remains important. The claim is not that one ordinary job guarantees wealth, fulfillment, ownership, or limitless upward mobility. It is that the more an institution invokes the hard-working-American ideal to demand exceptional loyalty, sacrifice, flexibility, and output, the stronger its obligation to make the return tangible and the future pathway credible.

> **The American work ethic without a reachable American Dream is all input and no output. At that point it is no longer a reciprocal ideal; it is extraction wearing the language of character.**

# 3. Repair First: The Ethical Order of Operations

Where repair remains safe and possible, quiet quitting is strongest when it follows an honest attempt rather than an untested assumption. That is truth-seeking, not a permission ritual.

## 3.1 Diagnose before accusing

First determine what can reasonably be known about what is happening.

Distinguish a structurally impossible workload from a temporarily difficult week. Separate what can be seen of understaffing, bad scheduling, missing equipment, poor sequencing, unclear priorities, training gaps, demand spikes, or simple misunderstanding. Notice where the real constraint appears to live and who has authority to investigate and change it.

Do not mistake suspicion for proof. Reconstruct what you reasonably can; the institution controls the fuller record.

The question is not merely, "Why am I suffering?" It is:

$$
\text{What combination of demand, staffing, equipment, policy, and priority produces this outcome?}
$$

## 3.2 Use the nearest safe and functioning channel

Start with the people who can still hear you without making the danger worse.

Where that route is safe and useful, communicate with the direct supervisor. Explain the problem in concrete terms. Separate facts from interpretations. Describe the current resources, the demanded outcomes, the conflict between them, and the smallest realistic repair.

A good direct supervisor is not merely another rung in a hierarchy. They can become a local witness to reality, a translator across institutional cultures, and a source of provenance when higher levels would otherwise see only an unexplained bad number.

That may not be the available route. A worker need not exhaust a channel reasonably expected to retaliate, discriminate, expose protected information, or create serious danger. Repair first asks for a good-faith attempt where a safe and functioning attempt exists—not ritual vulnerability before a hierarchy that has already made truth-telling hazardous.

## 3.3 Propose repair, not merely distress

Distress matters, but institutions often know how to ignore distress. They have more difficulty ignoring a clearly specified constraint paired with a feasible intervention.

Where possible, propose actions such as:

- adding labor at a specific bottleneck or time window;
- changing a production sequence;
- reducing or reordering lower-priority work;
- repairing or replacing a capacity-limiting tool;
- clarifying which standard takes precedence when standards conflict;
- creating an escalation rule for predictable overload;
- changing schedules to match observed demand rather than idealized demand.

The goal is not to do management's entire job for free. Offering one realistic intervention can test whether a functioning pathway exists without making the worker responsible for building it.

## 3.4 Force incompatible priorities into the open

When the available resources cannot satisfy all demands, do not privately absorb the contradiction.

Say, in substance:

> With the present staffing and demand, we can complete A and B safely, or A and C safely, but not A, B, and C at the demanded standard. Which takes priority?

This is one of the cleanest ethical instruments available to a worker. It transfers the tradeoff to the level that owns the authority to make it.

When management chooses a lawful and safe priority, follow it honestly. The unchosen work is then not an unexplained personal failure. It is the visible consequence of an explicit allocation decision. A priority order cannot erase the floor of safety, legality, honesty, or core professional integrity.

## 3.5 Escalate proportionally

Use the chain of command while it remains a communication channel. When it becomes only a shield against unwelcome information, use other ethical and available routes: documented escalation, established complaint systems, collective worker discussion, union representation where applicable, or external reporting for genuine safety or legal concerns.

Escalation should be truthful, proportional, and specific. It should aim at correction rather than humiliation.

# 4. Communicate in a Channel the Institution Can Read

Workers often discover that explanations are treated as opinions while money, labor hours, waste, overtime, throughput, and customer complaints are treated as reality.

That does not mean money is the message. Money is only a channel.

A negative number by itself is radically ambiguous. It may be decoded as understaffing, incompetence, poor management, bad equipment, unusual demand, laziness, or random variation. A financial consequence without causal provenance can communicate the opposite of what the worker intended.

The useful signal is not:

$$
\Delta \$ < 0.
$$

It is:

$$
(\text{staffing},\ \text{demand},\ \text{equipment},\ \text{priority decision})
\longrightarrow
\text{observable outcome}.
$$

The arrow records a causal hypothesis for the institution to investigate, not proof that these variables exhaust the cause.

A consequence communicates most clearly when whatever source-map is safely available remains attached.

Where it is safe, lawful, and useful, preserve an honest record of staffing levels, workload, material shortages, equipment failures, explicit priority decisions, and the resulting backlog or cost. Respect privacy and do not remove confidential or protected information merely to build a case. Do not falsify, exaggerate, or stage anything. The worker need not prove a unique cause. Management, with broader access to system data and control over resources, owns the deeper causal investigation.

The principle is:

> Do not create a failure in order to send a message. Stop erasing the evidence of a failure that already exists.

# 5. Ethical De-Buffering: Stop Counterfeiting Capacity

A workplace can appear to be functioning at the capacity management believes it possesses while actually relying on an invisible worker subsidy.

Schematically, let

$$
Y = F(D,N,E,H),
$$

where:

- \(Y\) is observed output;
- \(D\) is demand;
- \(N\) is staffing;
- \(E\) is equipment and process capacity;
- \(H\) is hidden heroic compensation: unsustainable pace, role absorption, skipped recovery, exceptional flexibility, constant rescue, and unrecorded cognitive or emotional labor.

When management treats output sustained by a large \(H\) as proof that \(N\) and \(E\) were sufficient, it learns the wrong lesson. The worker's competence becomes evidence against the worker's own request for help.

**Ethical de-buffering** means returning \(H\) toward a sustainable baseline while holding safety, honesty, and professional integrity fixed.

It may mean:

- working quickly but not frantically;
- taking agreed or required breaks;
- declining to cover chronic vacancies as an indefinite personal obligation;
- ending habitual off-clock problem-solving;
- refusing to treat every predictable rush as an unforeseeable emergency;
- allowing noncritical backlog to remain visible;
- reporting unfinished lower-priority work instead of hiding it through unpaid effort;
- requiring explicit authorization before taking on materially expanded duties;
- preserving enough capacity to perform tomorrow's work rather than consuming tomorrow to save today.

Heroic effort may be freely chosen during a genuine emergency. It cannot ethically be converted into the permanent baseline and then used to prove that the emergency staffing level is adequate.

> **The worker's body is not the slack variable in a staffing model.**

Ethical de-buffering is not making the system fail. It is refusing to counterfeit success.

But hidden heroic compensation can be the last remaining margin between an overloaded system and acute constraint collapse. If that margin is withdrawn, the consequences may not scale smoothly. A small reduction in hidden effort can move a brittle workplace across a threshold at which delays, mistakes, corner-cutting, conflict, and backlog amplify one another. That risk does not create an obligation to keep supplying the subsidy forever. The worker remains responsible for safety and truth within the choices they control. Management, which controls staffing, process, and priorities, bears the primary duty to plan for the real capacity that remains.

# 6. The "Fuck-It Factor": Acute Pathway Collapse

A workplace can be structurally broken over months and still fail moment by moment inside a single rush.

The model so far has described the long horizon: the worker speaks, proposes, compensates, and waits, but the connection between action and meaningful future outcome disappears. When the institution has also folded unowned excess into the job, quiet quitting proper is the long-horizon response: withdrawal of that excess after meaningful correction pathways close.

That long-horizon account needs a moment-to-moment counterpart.

> **The fuck-it factor**, as I use the term, is the felt transition from trying to satisfy the whole constraint set to judging, under time pressure and reduced mental clarity, that no available action can satisfy it all while action is still required. Something must give, so the person tries to sacrifice what appears to be the least important thing.

The deliberately blunt name preserves the experience as lived.

The fully compliant route may truly be absent, or it may only appear absent within the time, information, equipment, and authority available. The phenomenology is real in either case; which condition obtained is a later factual question.

A rush at work can require one person to satisfy many constraints simultaneously:

- preserve safety and sanitation;
- preserve product or service quality;
- meet queue and timing targets;
- sequence scarce equipment correctly;
- respond to customer-specific requirements;
- prepare for the next wave of demand;
- coordinate with coworkers;
- obey managerial priorities;
- regulate frustration and fear;
- and act now rather than deliberate indefinitely.

Let the live constraints at time \(t\) be

$$
\mathcal C_t = \{c_1,c_2,\ldots,c_n\},
$$

and let \(\mathcal A_t\) be the actions presently available. The fully compliant action-set is

$$
\mathcal A_t^{\mathrm{all}}
=
\{a\in\mathcal A_t : a\text{ satisfies every live constraint before its deadline}\}.
$$

Under sufficient demand, understaffing, equipment contention, interruption, and time pressure, that set can become empty:

$$
\mathcal A_t^{\mathrm{all}}=\varnothing.
$$

The worker does not thereby gain the option to stop time. Orders continue arriving. Food continues cooking. Customers continue waiting. A manager still expects an answer. Some action must occur. Stopping, slowing, refusing an unsafe instruction, escalating, or transferring control are themselves actions. Safety is not merely another performance target to trade against speed.

Descriptively—not as ethical permission to trade away safety—the resulting decision is approximately:

$$
a_t^*
\approx
\operatorname*{arg\,min}_{a\in\mathcal A_t}
\sum_i \widehat w_{i,t}\,\ell_i(a),
$$

where \(\ell_i(a)\) is the loss created by violating constraint \(c_i\), and \(\widehat w_{i,t}\) is the person's momentary estimate of how important that constraint is. The hats matter. Under emotional strain, divided attention, and severe urgency, those weights are being estimated with reduced clarity.

Plainly:

> **Fuck it. I cannot preserve everything. I will try to fuck the least important thing.**

This is not necessarily laziness, malice, or indifference. It names the lived turn into triage, not a moral permission slip. The choice can still be dangerous precisely because the person must choose while the surrounding conditions may also make choosing well less likely.

## 6.1 Overload, departure, and cascade

Overload, time pressure, stress, and interruption can raise ordinary error risk in some tasks and conditions whether or not the fuck-it factor appears.[^5] The research establishes no universal threshold or monotone law. The proposed second stage is Leah's synthesis: conscious triage introduces another chance to choose the wrong sacrifice or begin an unintended cascade. It may also avert a worse outcome. Existing research does not isolate an independent fuck-it-factor effect from the overload that produced it.

Three families must therefore remain distinct:[^6]

- **Intentional departures:** a person knowingly skips, delays, relaxes, or violates one requirement to preserve another. A departure is not automatically a mistake.
- **Unintentional errors:** a person forgets a dependency, misreads the situation, executes poorly, or sacrifices the wrong constraint.
- **Mixed cascades:** an intentional shortcut has an accidental consequence the person did not foresee or want.

Here, "intentional" does not mean that harm was desired. It means the person knew some requirement was being abandoned because no fully compliant route appeared live. A cascade can contain a deliberate departure, an accidental error, or both at different points. Calling all of them mistakes would erase the very distinction the model needs.

## 6.2 Repetition can normalize the workaround

One fuck-it event can be emergency triage. Repeated, unexamined workarounds can become familiar and harden into an operating regime when the cause is never repaired.[^7] Possible mechanisms include:

- the workaround becomes cognitively available and familiar;
- the absence of an immediate disaster makes the breach feel safer than it was;
- unfinished work and cleanup increase the next period's load;
- exhaustion, resentment, and shame may reduce future adherence;
- coworkers begin planning around the workaround;
- management sees that the shift "survived" and treats the overloaded condition as proven capacity.

Feedback, rest, repair, training, accountability, or a bad outcome can interrupt or reverse that pattern.

## 6.3 The short-horizon dual of quiet quitting

The two processes have the same underlying shape at different timescales:

$$
\text{long horizon: communicable and actionable pathways close}
\longrightarrow
\text{investment is withdrawn},
$$

$$
\text{short horizon: compliant operational pathways close under deadline}
\longrightarrow
\text{a constraint is sacrificed}.
$$

Quiet quitting proper is the long-horizon withdrawal of institutionalized excess when both the future pathway and a meaningful role-correction pathway have closed. The fuck-it factor is the acute, moment-to-moment response to an action-space in which no fully compliant move remains reachable before something must be done.

They can also reinforce each other. Chronic futility and resentment may make acute abandonment more available. Acute mistakes, rule departures, blame, and cleanup can further damage trust and close long-term pathways. A workplace can therefore enter a feedback loop:

$$
\begin{aligned}
\text{under-capacity}
&\rightarrow
\text{acute triage}
\rightarrow
\text{mistakes and conflict}
\\
&\rightarrow
\text{less trust and less slack}
\rightarrow
\text{still greater under-capacity}.
\end{aligned}
$$

This loop is proposed, not inevitable.

## 6.4 Why quiet quitting can have nonlinear consequences

Schematically, let effective momentary capacity be

$$
K_t = K_t^{\mathrm{base}} + H_t,
$$

where \(H_t\) is the hidden heroic compensation described above, and let \(W_t\) be the load. The remaining slack is

$$
S_t = K_t - W_t.
$$

When \(H_t\) is withdrawn, \(S_t\) may cross from barely positive to negative. Near saturation, some systems deteriorate nonlinearly rather than in neat proportion.[^8] Leah's proposed extension is that such a regime can leave no action satisfying every live constraint, creating the conditions in which the fuck-it factor arises.

This yields an uncomfortable but necessary conclusion:

> **Ethical quiet quitting may be justified and still be causally hazardous.**

Where hidden heroic effort was the final margin, the downstream change reveals dependence on that effort under those conditions. It need not identify every upstream cause before the institution acts; those with greater access and authority bear the duty to investigate them. The exact consequence may still be difficult to predict. Noncritical backlog or delay can disclose dependence on withdrawn effort under the observed conditions; customer, coworker, patient, or public harm cannot be treated as an honest measurement.

This does not restore an employer's claim to unlimited heroic labor. The worker should face foreseeable consequences honestly within what they can reasonably know and control. The institution, acting through those with the relevant authority, owns the system-level work: priority ladders, minimum staffing, rate limits, safe-stop conditions, handoffs, and surge protocols should be specified before the next rush rather than improvised inside it.

## 6.5 A warning across unequal power

Workers are human beings. Under enough pressure, they may make more mistakes. Under still more pressure, some will knowingly abandon one requirement to preserve another. Individual quiet quitting proper should not disguise retaliation or serious manufactured harm as an accidental boundary. Collective pressure is a different use of worker power; it should be named and owned as such. No worker can forecast a complete cascade from inside a system whose information and controls they do not possess.

Managers and executives are human beings too, but their power makes the scale different. The observable managerial analogue appears as "just get it done," refusal to hear another warning, concealment of bad numbers, indiscriminate blame, an unsafe labor cut, or an order that passes an impossible constraint set downward. A private mental state cannot be diagnosed from outside; the decision and its reach can. Because managerial decisions scale through other people, one such decision can become the working conditions of a department, store, or company.

> **Humanness is symmetric. Power is not.**

A worker's fuck-it event may damage one task or one shift. A manager's event can establish the conditions under which many workers are repeatedly forced into the same event. Corporate's version - "fuck it, hit the labor number" - can turn an acute failure of judgment into standing policy.

The warning is therefore exact:

> **A system that demands mutually incompatible standards is not maintaining all of those standards. It is outsourcing the choice of which standard will break to the most overloaded person at the worst moment.**

The ethical objective is not to demand superhuman adherence after the fully compliant action-set has already vanished. It is to prevent that set from vanishing: adequate staffing, explicit priority order, usable escalation, protected recovery, sufficient equipment, and authority to slow or stop when the safety floor cannot be preserved.

# 7. Employer Size Does Not Settle the Ethics

A large conglomerate may be able to absorb a financial loss, yet redirect the immediate cost onto a local team, a good supervisor, or vulnerable coworkers. A small business may be genuinely fragile, yet use that fragility to claim an unlimited moral entitlement to unpaid labor.

Size matters, but it does not decide the case.

The morally relevant question is where the cascade lands.

Ask:

1. Does the withdrawal expose an existing resource constraint, or create a new injury?
2. Will the institution absorb the consequence, or merely transfer it sideways onto coworkers?
3. Has foreseeable or intended third-party pressure been named and ethically weighed rather than disguised as accidental?
4. Is a decent local manager being made the sole bearer of a failure created above their authority?
5. Is the withdrawal proportional to the hidden subsidy being removed?
6. Does the action improve causal legibility, or merely increase pain?
7. Will the withdrawal remove enough slack to push another worker into acute overload or a fuck-it event, and can that risk be reduced without restoring the hidden subsidy?

For individual quiet quitting proper, the ethical aim is to move information upward without covertly manufacturing serious suffering sideways. Collective action can intentionally exert pressure; it should be named and judged as collective action.

A small business does not own a worker's life because it is fragile. A conglomerate does not become harmless because it is rich. A worker should consider foreseeable effects within what they can reasonably know and control. The institution, with greater information and authority, bears the larger duty to trace and prevent systemic cascades.

# 8. Quiet Quitting Proper: The Last Boundary

The following describe the clearest case for quiet quitting proper. They are a worker's self-audit, not an employer's permission form and not a fiction that both parties enter the judgment with equal power:

1. **The problem is persistent and material.** It is not merely one disappointing shift or one denied preference.
2. **Structural or managerial expectations exceed the defensible job baseline.** The gap may appear as a vague or contradictory written role, a material conflict between the role on paper and the job in practice, under-resourced volume or pace, incompatible priorities, or nominally optional excess enforced through pressure or penalty.
3. **Good-faith repair has been attempted where reasonably safe and useful.** The worker has communicated, proposed, clarified, or escalated through a viable pathway. Danger, credible retaliation, futility, or the absence of a functioning channel can excuse further attempts.
4. **The pathways are closed, inert, unreasonably costly, or offer only assimilation.** Further attempts predictably produce no repair, retaliation, unilateral relabeling of the excess as the job, or more uncompensated labor without meaningful access to change.
5. **The excess effort is discretionary and structurally masking.** It exceeds the sustainable core role and allows under-resourcing to appear adequate.
6. **Core duties remain intact.** Safety, honesty, feasible quality, and professional conduct are preserved.
7. **The withdrawal is proportional.** The worker removes the hidden subsidy rather than creating an artificial deficit.
8. **For individual quiet quitting proper, avoidable serious harm is not covertly manufactured or shifted onto people unable to repair the cause.** Collective pressure belongs to a different category.
9. **The purpose is boundary and truth, not punishment.** Anger may be present, but revenge does not govern the design.
10. **Foreseeable acute failure modes have been considered within the worker's knowledge and control.** Where reasonably safe and useful, the worker has warned which duties may become infeasible and requested a priority order. Management remains responsible for system-level foresight, staffing, and safe-stop design.

At that point, the worker may ethically:

- perform the defined role competently and sustainably;
- decline chronic role creep without compensation, authority, or agreement;
- stop volunteering for predictable emergencies produced by normal planning;
- maintain agreed availability rather than permanent accessibility;
- refuse impossible combinations and request a priority decision;
- stop taking personal ownership of outcomes determined by managerial resource choices;
- conserve time and energy for health, relationships, education, art, organizing, job search, or another future;
- remain courteous without manufacturing enthusiasm.

Quiet quitting proper is not the abandonment of standards. It is the narrowing of scope to the standards the institution actually resources.

# 9. The Non-Negotiable Invariants

For individual quiet quitting proper, the following remain fixed. They distinguish a personal boundary from concealed retaliation; they are not a universal tactics code for collective action.

## Safety remains fixed

Do not compromise food safety, physical safety, sanitation, medical safety, public safety, or any other duty whose failure can seriously harm another person.

## Honesty remains fixed

Do not falsify records, misstate capacity, invent incidents, conceal urgent defects, or manipulate numbers. A truthful signal is the entire point.

## Core professional integrity remains fixed

Do not intentionally produce bad work where competent work remains feasible within the real role and available resources. Scope may contract; integrity does not.

## Pressure must not be disguised

Individual quiet quitting should not disguise intentional pressure or serious manufactured harm as an accidental byproduct. That does not mean the less powerful must remain harmless enough to be ignored.

## Forced triage remains visible

When the full constraint set cannot be satisfied, do not falsely reclassify the sacrificed requirement as completed, optional, or normal. Where it is safe and within the worker's knowledge, name what gave way. Determining the deeper cause and what resources would preserve it next time belongs primarily to those who control the system. A workaround that remains invisible can become tomorrow's official capacity assumption.

## Proportionality remains fixed

Withdraw what was being improperly extracted. Do not add retaliation on top of the withdrawal.

## Accountability remains fixed

A broken institution does not erase responsibility for one's own actions. Explanation is not exculpation. A boundary must still be owned.

## Collective action is a different use of power

> **Do what you feel is right—but do not mistake the feeling for proof. Test what is true. Know the consequences as far as you can. Own what you choose.**

A strike, boycott, slowdown, or coordinated work-to-rule can intentionally create pressure. Test its factual premises and search for disconfirmation. Distinguish what is known from what is predicted, feared, or hoped. Map foreseeable consequences and honest uncertainty; tell the truth about who chose the action. Owning deliberate pressure is not self-condemnation, and it does not transfer responsibility for a brittle or exploitative system onto the worker. Responsibility remains distributed according to choice, knowledge, power, and control.

# 10. The Ethical Quiet Quitting Test

Use the questions that bear on the actual situation; no single answer is a gate. Before quiet quitting proper, ask:

- Have I identified the actual constraint rather than merely named my frustration?
- Have I tried the nearest realistic repair pathway where doing so is reasonably safe and useful?
- Have I communicated the problem in terms the receiver can act upon?
- Have I proposed at least one feasible intervention or priority choice?
- Have I preserved an honest causal record where safe, lawful, and useful?
- Is "get another job" a genuinely live option, or only a formal possibility that ignores search costs, wage gaps, schedule, benefits, transportation, and survival risk?
- Does this workplace offer a credible tangible return for exceptional effort - pay, autonomy, mastery, ownership, advancement, belonging, or a future I can recognize as mine - or only the identity reward of proving I can endure?
- Is the language of the "hard-working American" being used to demand dream-level sacrifice while the actual job offers no credible pathway toward American-Dream goods such as security, ownership, mobility, independence, or a self-directed future?
- Am I judging myself against someone whose personal resonance, team, timing, or opportunity makes this work a materially different object for them?
- Is the effort I plan to withdraw truly discretionary, uncompensated, unsustainable, or outside the reasonably defined role?
- Will the withdrawal reveal an existing limit rather than manufacture a new failure?
- Am I quiet quitting individually, or choosing a collective pressure tactic that should be named and evaluated on its own terms?
- What acute overloads may appear when the hidden buffer is removed?
- Which requirement is most likely to be sacrificed during the next rush, and is that requirement ethically eligible for sacrifice?
- Have I requested an explicit priority order and identified a safe-stop condition before the fully compliant action-set disappears?
- Are safety, honesty, feasible quality, and coworker welfare protected?
- If this is individual quiet quitting, is its scale and timing proportional to the hidden subsidy rather than disguising a different tactic?
- For individual quiet quitting proper, am I trying to stop an extraction, or trying to make someone suffer?
- Would I be willing to describe the action plainly to a fair-minded observer?
- If management repaired the pathway in good faith, would I be willing to reconsider?

# 11. The Worker's Pledge

This pledge is not a strict-adherence protocol, checklist, or employer-facing test. It is a set of reminders: do not self-sacrifice to preserve institutional appearances; exercise the power you have—or should have—consciously and ethically; and remain answerable to reality. Capital-T Truth is the aim, while human understanding is partial and revisable. Test what you think you know, seek what could prove you wrong, distinguish knowledge from inference or hope, and revise when better evidence arrives. Fidelity to reality is not obedience to authority.

Where a safe and functioning pathway exists, we will try to repair before we retreat.

We will not lie; when truth-telling is punished, silence is not falsehood.

We will distinguish a hard day from a structurally impossible demand.

We will not confuse endurance with loyalty, or exhaustion with excellence.

We will not treat hardship as proof of virtue or another person's resonance as a universal moral baseline.

We will work hard where effort builds something tangibly worth building, not merely to prove that we are hard.

We will not confuse the American work ethic with an obligation to keep feeding a bargain after work has been severed from the dream it was supposed to make reachable.

We will work to build an owned future, not merely perform the identity of people who deserve one.

We will not make impossible workloads appear ordinary by consuming ourselves in private.

We will not mistake assimilation for correction.

We will make those with authority own the choice among incompatible priorities.

Where we can do so safely, we will name impossible constraint sets before the fuck-it factor chooses in silence.

When something must give, we will protect the safety floor and make the sacrificed requirement visible.

We will not treat a shift that merely survived as proof that it was safely or adequately staffed.

We will not mistake a theoretically available exit for a live one.

We will preserve the connection between resource decisions and their consequences.

In individual quiet quitting proper, we will not manufacture failure and misname it as withdrawal.

We will not falsify.

We will not conceal serious safety risks or manufacture serious harm and call it quiet quitting.

When we act collectively, we will test what is true, name intended pressure, and own what we choose within what we can reasonably know and control.

We will give honest labor for honest compensation.

We will help during genuine emergencies without allowing emergency effort to become the invisible permanent baseline.

We will withdraw the hidden subsidy, not our integrity.

And when every reasonably safe ethical pathway to improvement is closed, inert, unsafe, or absent, we reserve the right to quiet quit proper.

# 12. A Message to Managers

Your most capable employees may be hiding your worst process failures.

When a worker stops overfunctioning, the dysfunction may not be new. It may only have become visible. Do not ask first, "How do we make this person care again?" Ask:

> What had this person been supplying that our official staffing, process, and compensation model did not contain?

A hierarchy that carries commands downward but cannot carry unwelcome reality upward is not functioning as a communication system. It is functioning as a performance system in which each level edits the truth to look competent to the level above.

Repair the channel before demanding renewed investment.

When operative demands exceed the defensible baseline—through contradiction, role expansion, or impossible volume, pace, staffing, equipment, or priorities—repair the work system or renegotiate the expansion. Do not rewrite the description, demand assimilation, and call that clarity. If a competent employee now looks merely average, the defined work has not failed; the invisible subsidy has stopped.

Humane restraint is not pathological tolerance. Managers may act against genuine misconduct. Their obligation is to distinguish it from a boundary, dissent, organizing, or work-to-rule, and to respond proportionately rather than treating every loss of discretionary obedience as betrayal. Greater power requires better discrimination, not thinner skin.

Ethical quiet quitting proper is a warning case, not a claim that structurally produced withdrawal always arrives with an explicit ethic attached. It describes one explicitly articulated attempt to preserve truth, safety, competent baseline work, and fairness while ending an unowned subsidy. Other workers may arrive at a similar posture through the same kind of environment, filtered through their own circumstances and values, without naming or analyzing it this way. Do not mistake their lack of a manifesto for lack of cause, and do not let a case of apathy, refusal, sabotage, or collective pressure elsewhere become a shortcut for classifying competent baseline work here. Because management controls classification and discipline, its duty to distinguish and repair is greater.

Do not mistake your most personally resonant employee for the neutral human baseline. A worker who loves the mission, trusts the team, sees a credible future, or has unusually favorable life conditions may freely invest far more than another competent worker can rationally sustain. That extra investment is real, but it is contingent. It is not evidence that everyone else lacks character.

If you want discretionary grind, make the return tangible: pay, autonomy, skill, ownership, security, credible advancement, meaningful influence, trustworthy leadership, and a mission people can actually share. Slogans cannot manufacture resonance, and passion cannot be converted into permanent staffing capacity.

Do not invoke the "hard-working American" while removing the worker's credible route to the American Dream. If you ask for dream-level loyalty, flexibility, sacrifice, and output, then wages, security, advancement, ownership, or meaningful influence must make that sacrifice intelligible as investment. National mythology cannot repair a severed causal pathway, and patriotism cannot be booked as compensation.

Do not answer a worker's boundary with "then leave." Continued attendance may mean that rent, food, medicine, transportation, or health coverage still depend on the paycheck; it does not prove that the conditions are acceptable. If the only options you leave are unsustainable overfunctioning or immediate material insecurity, the predictable middle state is quiet quitting, not a clean departure.

Reward early warning. Permit explicit priority calls. Distinguish a worker's boundary from insubordination. Do not punish the person who makes a hidden constraint measurable. When an employee says that A, B, and C cannot all be completed safely with the available resources, management's job is to allocate, not to demand that the contradiction disappear inside the employee.

Do not model overload as a simple reduction in speed. Near a limit, ordinary error risk can rise. Beyond it, an employee may have to choose which requirement gives way while the same pressure makes that tradeoff harder to judge. If you insist that every target remains mandatory after the fully compliant action-set is empty, you have not preserved the standards; you have hidden the selection of the broken standard.

Watch for your own fuck-it factor. We cannot see your private state, but we can judge the decision and its reach. "Just get it done" without a coherent route is an observable refusal to own the tradeoff. Cutting labor to hit a number, suppressing a warning to look competent upward, or blaming a worker because the structural explanation is inconvenient can impose the same operational constraint collapse at a higher order. The power difference means your decision can become everyone else's working conditions.

Quiet quitting proper can therefore expose unanticipated or unwanted consequences. Treat those effects as evidence relevant to real capacity and dependence on hidden effort—not as proof of a unique cause, and not automatically as proof of bad character. Ask what margin disappeared, which constraint became impossible, and why the organization had made one person's unsustainable compensation the final safety system.

The fastest way to produce quiet quitting is to make voice causally irrelevant while continuing to demand emotional ownership. The fastest way to turn quiet quitting into a dangerous cascade is to leave every priority nominally mandatory after the resources needed to satisfy them have already been removed.

# Conclusion: A Last Boundary, Not a First Weapon

Quiet quitting should be a last ethical boundary, not a first weapon.

We repair first because work can matter, coworkers matter, customers matter, and institutions can sometimes learn. Testing what can safely be tested helps the worker distinguish a repairable problem from a closed world. It does not require doing management's work or surviving every channel before a boundary becomes legitimate.

But repair is not a lifelong obligation to bleed into a closed circuit.

When words fail, records are ignored, priorities remain impossible, and the institution expects private sacrifice to bridge a structural gap it refuses to acknowledge, the worker may ethically stop paying that subsidy.

Where exit is not yet a live option, quiet quitting can preserve the income and recover the bandwidth required to make another future reachable.

This manifesto is not anti-grind. It defends the right to invest deeply where effort has somewhere real to go, and the right not to turn being ground down into proof of identity. Quiet quitting may preserve ambition by reclaiming it from a system that cannot receive it.

Nor is quiet quitting necessarily a rejection of the American Dream. It may be evidence that the worker still wants an owned future but no longer believes this employer connects additional sacrifice to it. The hard-working-American identity cannot indefinitely survive the disappearance of the Dream-side pathway. When the bargain becomes all work and no reachable future, withdrawal is not mysterious; it is diagnostic.

But the withdrawal is not guaranteed to be mechanically clean. In a brittle system, removing hidden slack can expose conditions associated with ordinary error risk and forced triage; in Leah's proposed model, those conditions can also make the fuck-it factor more likely. Foreseeable consequences should be faced honestly, but responsibility is not divided fifty-fifty: it follows choice, knowledge, power, and control. The worker owns the acts they choose. The institution bears the larger systemic burden where it designed or maintained the constraint set. That is not a reason to preserve exploitation. It is a reason to repair early, specify priorities honestly, and never let one person's heroics become the only barrier between normal operations and acute collapse.

We do not manufacture failure. We stop concealing it.

We do not abandon duty. We define it.

We do not withdraw care from human beings. We withdraw unlimited institutional access to ourselves.

**Repair first. Make the constraints legible. Withdraw the hidden subsidy. Then, only when all else fails, quiet quit proper.**

**We withdraw the subsidy, not the integrity.**

---

*Scope note:* This is an ethical framework, not legal advice. Employment contracts, collective bargaining agreements, workplace policies, professional duties, and applicable law may create additional obligations or protections.

*Evidence and conceptual provenance:* This is a case-anchored normative manifesto, not a population study. The thesis, ethical-de-buffering framework, and fuck-it-factor coinage are Leah's synthesis, developed from lived experience and her TLICA work on agency, semantic interoperability, configurational action, and the separation of acts, outcomes, cascades, responsibility, and accountability. Adjacent research supports parts of the surrounding risk ecology; it does not validate quiet quitting proper, ethical de-buffering, or the fuck-it factor as scientific constructs.

*AI-development disclosure:* The author used OpenAI's ChatGPT to test the argument, identify counterarguments and candidate sources, and draft and revise portions of the prose. The originating thesis, lived-experience framing, coined concepts, and editorial direction are the author's. Publication remains contingent on the author's personal review of the complete manuscript, independent checking of factual claims and citations, and approval of the final positions and wording. Responsibility for any released text remains with the author.

# Notes

[^1]: Elizabeth W. Morrison, "Employee Voice and Silence," *Annual Review of Organizational Psychology and Organizational Behavior* 1 (2014): 173-197, https://doi.org/10.1146/annurev-orgpsych-031413-091328. The review describes organizational and individual conditions that can encourage or inhibit employee voice; it does not establish that every apparently closed pathway is in fact closed.

[^2]: Board of Governors of the Federal Reserve System, *Economic Well-Being of U.S. Households in 2025* (Washington, DC, May 2026), https://www.federalreserve.gov/publications/files/2025-report-economic-well-being-us-households-202605.pdf; West Health and Gallup, "One in Four U.S. Employees Locked in Jobs for Health Insurance," July 21, 2026, https://news.gallup.com/poll/712166/one-four-employees-locked-jobs-health-insurance.aspx; Daniel Schneider and Kristen Harknett, "Consequences of Routine Work-Schedule Instability for Worker Health and Well-Being," *American Sociological Review* 84, no. 1 (2019): 82-114, https://doi.org/10.1177/0003122418823184. These sources document forms of financial fragility, benefit dependence, and schedule instability in defined U.S. samples. They do not establish why any particular worker remains in a job or that the schedule study is nationally representative.

[^3]: Alison R. Buck, "The Price of Consent: Identity Wages in the Games Industry," *Journal of Contemporary Ethnography* 51, no. 6 (2022): 868-894, https://doi.org/10.1177/08912416221085558.

[^4]: Library of Congress, "The American Dream," classroom materials, accessed August 16, 2026, https://www.loc.gov/classroom-materials/american-dream/; Raj Chetty et al., "The Fading American Dream: Trends in Absolute Income Mobility Since 1940," *Science* 356, no. 6336 (2017): 398-406, https://doi.org/10.1126/science.aal4617; Gabriel Borelli, "Americans Are Split over the State of the American Dream," Pew Research Center, July 2, 2024, https://www.pewresearch.org/short-reads/2024/07/02/americans-are-split-over-the-state-of-the-american-dream/. Chetty and colleagues estimate that roughly 90 percent of the 1940 birth cohort had higher inflation-adjusted household incomes than their parents at about age thirty, compared with roughly half of people born in the 1980s. The materials do not reduce the Dream to income, establish equal access, or prove Leah's mechanism. Her input/output account is one influential strand; "all input and no output" refers to exceptional sacrifice **here**, not the literal absence of wages or present benefits.

[^5]: James L. Szalma, Peter A. Hancock, and Sean Quinn, "A Meta-Analysis of the Effect of Time Pressure on Human Performance," *Proceedings of the Human Factors and Ergonomics Society Annual Meeting* 52, no. 19 (2008): 1513-1516, https://doi.org/10.1177/154193120805201944; Grant S. Shields, Matthew A. Sazma, and Andrew P. Yonelinas, "The Effects of Acute Stress on Core Executive Functions: A Meta-Analysis and Comparison with Cortisol," *Neuroscience & Biobehavioral Reviews* 68 (2016): 651-668, https://doi.org/10.1016/j.neubiorev.2016.06.038; Johanna I. Westbrook et al., "Association of Interruptions with an Increased Risk and Severity of Medication Administration Errors," *Archives of Internal Medicine* 170, no. 8 (2010): 683-690, https://doi.org/10.1001/archinternmed.2010.65; Seyed M. Hashemian and Konstantinos Triantis, "Production Pressure and Its Relationship to Safety: A Systematic Review and Future Directions," *Safety Science* 159 (2023): 106045, https://doi.org/10.1016/j.ssci.2022.106045. Together they support context-dependent risk, not a universal effect size or the coined factor. The factor is Leah's deliberately blunt phenomenological shorthand, not a validated scale, diagnosis, law, legal defense, or excuse.

[^6]: James Reason et al., "Errors and Violations on the Roads: A Real Distinction?" *Ergonomics* 33, nos. 10-11 (1990): 1315-1332, https://doi.org/10.1080/00140139008925335; Samuel J. Alper and Ben-Tzion Karsh, "A Systematic Review of Safety Violations in Industry," *Accident Analysis & Prevention* 41, no. 4 (2009): 739-754, https://doi.org/10.1016/j.aap.2009.03.013. The sources support distinguishing unintentional errors from intentional rule departures; neither implies that every intentional departure is malicious or mistaken.

[^7]: Debra S. Debono et al., "Nurses' Workarounds in Acute Healthcare Settings: A Scoping Review," *BMC Health Services Research* 13 (2013): 175, https://doi.org/10.1186/1472-6963-13-175; Anita L. Tucker, Amy C. Edmondson, and Steven Spear, "When Problem Solving Prevents Organizational Learning," *Journal of Organizational Change Management* 15, no. 2 (2002): 122-137, https://doi.org/10.1108/09534810210423008; National Aeronautics and Space Administration, *NASA Human Factors Handbook*, NASA-HDBK-8709.25, version 1.4 (2023), https://standards.nasa.gov/sites/default/files/standards/NASA/Baseline/4/NASA-HDBK-870925-Baseline-14.pdf; Columbia Accident Investigation Board, *Report, Volume I* (2003), https://ntrs.nasa.gov/citations/20030093634. These sources support conditional organizational processes of workaround persistence and normalization, not a mechanical decline in one person's threshold.

[^8]: J. F. C. Kingman, "The Single Server Queue in Heavy Traffic," *Proceedings of the Cambridge Philosophical Society* 57, no. 4 (1961): 902-904, https://doi.org/10.1017/S0305004100036094; David D. Woods, "The Theory of Graceful Extensibility: Basic Rules That Govern Adaptive Systems," *Environment Systems and Decisions* 38 (2018): 433-457, https://doi.org/10.1007/s10669-018-9708-3. These support possible nonlinear deterioration near saturation, not a fitted workplace prediction.
